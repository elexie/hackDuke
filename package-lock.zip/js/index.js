var phoneNum=704;

$(document).ready(function(){
	var imgUrl;
	const fill = document.querySelectorAll('.rowImg');
	const empties = document.querySelectorAll('.orgEmpty');

	// Fill listeners
	// Loop through rowImg boxes and add listeners
	for (const fil of fill) {
	 	fil.addEventListener('dragstart', dragStart);
		fil.addEventListener('dragend', dragEnd);
	}

	// Loop through empty boxes and add listeners
	for (const empty of empties) {
	  empty.addEventListener('dragover', dragOver);
	  empty.addEventListener('dragenter', dragEnter);
	  empty.addEventListener('dragleave', dragLeave);
	}


	
	// Drag Functions
	// act1
	function dragOver(e) {
	  e.preventDefault();
	}

	// act2
	function dragEnter(e) {
	  e.preventDefault();
	  this.className += ' hovered';//fine
	  $(this).css({'background-image':"url("+imgUrl+")",
	  'background-repeat':'no-repeat',
	  'background-position':'center',
	  'background-size':'cover'
	  });
	}

	// act3
	function dragLeave() {
	  this.className = 'orgEmpty';//fine
	//  this.classList.remove('img1');
	}

	//3 other drags
	function dragStart() {
	  this.className += ' hold';
	  imgUrl=$(this).css('background-image');
	  imgUrl = imgUrl.replace('url(','').replace(')','').replace(/\"/gi, "");
	  //alert(imgUrl);
	//  setTimeout(() => (this.className = 'invisible'), 0);
	}

	function dragEnd() {
		this.className = 'rowImg';
	}
	function dragDrop() {
	// this.append('#img1');
	 alert('yikes');
	}
	
	//doTwilio();
	$("#submitButton").click(function(){
	    phoneNum= $('input').val();
		alert("Thank you for the donations\nConfirmation message sent to "+phoneNum);
	//	doTwilio();
	})

	
});
/*
function doTwilio(){
 var TwilioSMS = (function($) {

  var accountSid = 'MGa19328c02a87c6570cfdc9c18d25cf0d ';
  var authToken = 'd013a60b41463361112c15aa63b98937';

  var testEndpoint = 'https://api.twilio.com/2010-04-01/Accounts/' + accountSid + '/SMS/Messages.json';
  var liveEndpoint = 'https://api.twilio.com/2010-04-01/Accounts/' + accountSid + '/Messages.json';

  var sendMessage = function(to, from, body, successCallback, failCallback) {
    var data = {
      To: to,
      From: from,
      Body: body
    };

    $.ajax({
      method: 'POST',
      url: testEndpoint,
      data: data,
      dataType: 'json',
      contentType: 'application/x-www-form-urlencoded', // !
      beforeSend: function(xhr) {
        xhr.setRequestHeader("Authorization",
          "Basic " + btoa(accountSid + ":" + authToken) // !
        );
      },
      success: function(data) {
        console.log("Got response: %o", data);

        if (typeof successCallback == 'function')
          successCallback(data);
      },
      error: function(jqXHR, textStatus, errorThrown) {
        console.log("Request failed: " + textStatus + ", " + errorThrown);

        if (typeof failCallback == 'function')
          failCallback(jqXHR, textStatus, errorThrown);
      }
    });
  }

  return {
    sendMessage: sendMessage
  };

})//end of var TwilioSMS
			TwilioSMS.sendMessage(
				  phoneNum,
				  '+8038100427',
				  'Thank you for the donations',

				  function ok() {
					console.log("Message sent!");
				  },
				  function fail() {
					console.log("Failed to send your message!");
				  }
);
}//end of doTwilio()

*/